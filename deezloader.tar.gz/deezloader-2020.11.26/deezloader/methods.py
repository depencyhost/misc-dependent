#!/usr/bin/python3

method_get_song_data = "song.getData"
method_get_album_data = "album.getData"
method_get_song_page = "deezer.pageTrack"
method_get_songs_data = "song.getListData"
method_get_user_data = "deezer.getUserData"
method_get_playlist_data = "playlist.getSongs"
method_get_album = "song.getListByAlbum"
method_get_lyric = "song.getLyrics"