#!/usr/bin/python3

answers = ["Y", "y", "Yes", "YES"]
spotify_client_id = "c6b23f1e91f84b6a9361de16aba0ae17"
spotify_client_secret = "237e355acaa24636abc79f1a089e6204"