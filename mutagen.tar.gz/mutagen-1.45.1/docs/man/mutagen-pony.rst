==============
 mutagen-pony
==============

---------------------------------
scan a collection of MP3 files
---------------------------------

:Manual section: 1


SYNOPSIS
========

**mutagen-pony** *directory* ...


DESCRIPTION
===========

**mutagen-pony** scans any directories given and reports on the kinds of
tags in the MP3s it finds in them. Ride the pony.

It is primarily intended as a debugging tool for Mutagen.


AUTHORS
=======

Michael Urman and Joe Wreschnig
