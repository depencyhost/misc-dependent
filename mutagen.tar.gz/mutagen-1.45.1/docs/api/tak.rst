TAK
===

.. automodule:: mutagen.tak

.. autoclass:: mutagen.tak.TAK
    :show-inheritance:
    :members:

.. autoclass:: mutagen.tak.TAKInfo
    :members:
