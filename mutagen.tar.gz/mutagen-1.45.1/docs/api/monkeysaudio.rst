Monkey's Audio
==============

.. automodule:: mutagen.monkeysaudio

.. autoclass:: mutagen.monkeysaudio.MonkeysAudio
    :show-inheritance:
    :members:

.. autoclass:: mutagen.monkeysaudio.MonkeysAudioInfo
    :show-inheritance:
    :members:
